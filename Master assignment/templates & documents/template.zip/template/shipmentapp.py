import os
import sys
import json
import sqlite3

from vessel import Vessel
from port import Port
from shipment import Shipment


def main():
    pass


if __name__ == "__main__":
    main()
